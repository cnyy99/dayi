package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Monster {
	boolean frighten(int d){
		System.out.println("arrrgh");
		return true;
	}
}
