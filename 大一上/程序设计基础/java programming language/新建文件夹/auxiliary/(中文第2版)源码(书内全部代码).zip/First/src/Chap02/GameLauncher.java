package Chap02;

//2013.03.19
//Michel
public class GameLauncher {
	public static void main(String[] args){
		GuessGame game=new GuessGame();
		game.startGame();
	}
}
