package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class UseADuck {
	public static void main(String[] args){
		Duck d = new Duck(42);   //传值给构造函数
		
		Duck d2 = new Duck();    //不带参数时
	}
}
