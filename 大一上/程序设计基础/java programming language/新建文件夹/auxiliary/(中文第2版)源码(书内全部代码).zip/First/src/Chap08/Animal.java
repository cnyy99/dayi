package Chap08;

/**
 * 2013.03.26
 * Michel
 */
public class Animal {

}
