package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class B extends A {
	void m1(){
		System.out.print("B's m1, ");
	}
}
