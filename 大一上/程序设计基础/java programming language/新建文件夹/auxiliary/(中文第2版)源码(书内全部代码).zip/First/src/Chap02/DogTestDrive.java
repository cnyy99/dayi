package Chap02;

//2013.03.19
//Michel
public class DogTestDrive {
	public static void main(String[] args){
		//测试Dog类
		Dog d=new Dog();
		d.size=40;
		d.bark();
	}
}