package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class TestHippo {
	public static void main(String[] args){
		System.out.println("Starting..."); 
		Hippo h = new Hippo("Buffy");
		System.out.println(h.getName());
	}
}
