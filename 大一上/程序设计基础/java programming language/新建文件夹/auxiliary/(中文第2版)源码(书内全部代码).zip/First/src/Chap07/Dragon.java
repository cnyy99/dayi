package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Dragon extends Monster{
	boolean frighten(int degree){
		System.out.println("breath fire");
		return true;
	}
}
