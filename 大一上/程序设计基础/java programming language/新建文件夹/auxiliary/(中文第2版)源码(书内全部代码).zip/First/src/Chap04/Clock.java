package Chap04;

/**
 * 2013.03.21
 * Mihcel
 */
public class Clock {
	String time;
	
	void setTime(String t){
		time = t;
	}
	
	//void getTime(){
	String getTime(){      //get要有返回值
		return time;
	}
}
