package Chap02;

//2013.03.19
//Michel
public class TapeDeck {
	boolean canRecord = false;
	void playTape() {
		System.out.println("tape playing");
	}
	void recordTape() {
		System.out.println("tape recording");
	}
}
