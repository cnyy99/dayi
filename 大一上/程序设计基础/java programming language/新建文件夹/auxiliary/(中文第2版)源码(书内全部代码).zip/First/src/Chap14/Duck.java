package Chap14;

/**
 * 2013.04.08
 * Michel
 */
public class Duck {

}
