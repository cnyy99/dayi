package Chap02;

//2013.03.19
//Michel
public class DrumKit {
	boolean snare = true;
	boolean topHat = true;
	
	void playSnare() { 
		System.out.println("bang bang ba-bang");
	} 
	
	void playTopHat () { 
		System.out.println("ding ding da-ding");
	} 
} 