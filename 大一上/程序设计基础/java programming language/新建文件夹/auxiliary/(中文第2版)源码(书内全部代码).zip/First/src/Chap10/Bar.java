package Chap10;

/**
 * 2013.03.27
 * Michel
 */
public class Bar {
	//静态final变量初始化方法2
	public static final double BAR_SIGN;
	
	static{
		BAR_SIGN = (double) Math.random();
	}
}
