package Chap03;


/**
 * 2013.03.20
 * Michel
 */
public class Books {
	String title;
	String author; 
}
