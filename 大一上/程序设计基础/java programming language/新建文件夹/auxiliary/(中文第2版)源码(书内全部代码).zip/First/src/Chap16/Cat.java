package Chap16;

/**
 * 2013.04.17
 * Michel
 */
public class Cat extends Animal {
	void meow(){
		
	}
}
