package Chap10;

/**
 * 2013.03.28
 * Michel
 * final的class
 */
public final class MyMostPerfectClass {
	//final类不能被继承
}
