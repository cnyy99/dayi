package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Doctor {
	boolean workAtHospital;  //不加限定修饰符的，默认为public
	
	public void treatPatient(){
		//执行检查
		System.out.println("执行检查");
	}
}
