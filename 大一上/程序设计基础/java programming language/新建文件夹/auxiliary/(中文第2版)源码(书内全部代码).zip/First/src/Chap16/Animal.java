package Chap16;

/**
 * 2013.04.17
 * Michel
 */
public class Animal {
	void eat(){
		System.out.println("animal eating");
	}
}
