package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class Car {
	public Car(String name){
		System.out.println("Car's name is " + name);
	}
}
