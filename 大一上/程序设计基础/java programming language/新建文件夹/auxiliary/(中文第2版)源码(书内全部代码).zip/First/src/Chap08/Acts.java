package Chap08;

/**
 * 2013.03.27
 * Michel
 */
public class Acts extends Picasso{
	public int iMethod(){
		return 5;
	}
}
