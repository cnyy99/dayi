package Chap15;

/**
 * 2013.04.15
 * Michel
 * 用两个都想把余额更新的线程来展示丢失更新
 */
public class TestSyncTest {
	public static void main(String[] args){
		TestSync job = new TestSync();
		Thread a = new Thread(job);
		Thread b = new Thread(job);
		a.start();
		b.start();
	}
}