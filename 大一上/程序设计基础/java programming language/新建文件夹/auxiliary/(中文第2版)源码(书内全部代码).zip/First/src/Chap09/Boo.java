package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class Boo {
	public Boo(int i){}
	public Boo(String s){}
	public Boo(String s, int i){}
}
