package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class C extends B {
	void m3(){
		System.out.print("C's m3, "+(ivar+6));
	}
}
