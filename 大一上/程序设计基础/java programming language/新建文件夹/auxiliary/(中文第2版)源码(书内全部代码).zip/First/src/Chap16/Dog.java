package Chap16;

/**
 * 2013.04.17
 * Michel
 */
public class Dog extends Animal {
	void bark(){
		
	}
}
