package Chap11;

/**
 * 2013.03.29
 * Michel
 */
public class Laundry {
	public void doLaundry() throws PantsException, LingerieException {
		//有可能抛出两个异常的程序代码
	}
}
