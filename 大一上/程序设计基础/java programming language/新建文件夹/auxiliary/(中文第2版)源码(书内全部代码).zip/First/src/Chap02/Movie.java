package Chap02;

//2013.03.19
//Michel
public class Movie {
	String title;
	String genre;
	int rating;
	
	void playIt(){
		System.out.print("Playing the moive");
	}
}
