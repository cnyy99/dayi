package Chap11;

/**
 * 2013.03.29
 * Michel
 */
public class PantsException extends Exception {
	
}
