package Chap11;

/**
 * 2013.03.29
 * Michel
 */
public class ClothingException extends Exception {

}
