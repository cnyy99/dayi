package Chap11;

/**
 * 2013.03.29
 * Michel
 * 假设ScaryException继承自Exception。。。
 */
public class ScaryException extends Exception {

}
