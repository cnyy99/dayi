package Chap08;

/**
 * 2013.03.26
 * Michel
 */
public class Dog extends Canine implements Pet {
	//必须实现所有的抽象方法
	public void beFriendly(){
		
	}
	
	public void play(){
		
	}
	
	public void roam(){
		
	}
	
	public void eat(){
		
	}
}
