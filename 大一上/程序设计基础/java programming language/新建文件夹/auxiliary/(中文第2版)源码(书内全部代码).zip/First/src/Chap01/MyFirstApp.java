package Chap01;

//2013.03.18
//Michel
public class MyFirstApp {
	public static  void main(String[] args){
		 System.out.println("I Rule!");       //println会在末尾换行
		 System.out.print("Hello World");
		 System.out.print("!");
	}
}