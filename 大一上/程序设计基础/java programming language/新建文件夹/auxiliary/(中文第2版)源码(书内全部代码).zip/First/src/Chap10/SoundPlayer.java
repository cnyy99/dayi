package Chap10;

/**
 * 2013.03.27
 * Michel
 */
public class SoundPlayer {

	void playSound(String s){
		System.out.println("play " + s);
	}
}
