package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class Bees {
	Honey[] beeHA;
}
