package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class A {
	int ivar = 7;
	
	void m1(){
		System.out.print("A's m1, ");
	}
	
	void m2(){
		System.out.print("A's m2, ");
	}
	
	void m3(){
		System.out.print("A's m3, ");
	}
}
