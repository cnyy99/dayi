package Chap08;

/**
 * 2013.03.27
 * Michel
 */
public class Picasso implements Nose {
	public int iMethod(){
		return 7;
	}
}
