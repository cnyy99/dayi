package Chap02;

//2013.03.19
//Michel
public class Dog {
	int size;
	String breed;
	String name;
	
	void bark(){
		System.out.println("Ruff! Ruff!");
	}
}
