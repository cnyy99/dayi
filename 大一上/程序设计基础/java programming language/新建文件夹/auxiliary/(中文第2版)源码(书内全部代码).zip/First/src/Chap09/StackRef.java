package Chap09;

/**
 * 2013.03.27
 * Michel
 */
public class StackRef {

	public void foof(){
		barf();
	}
	
	public void barf(){
		//Duck d = new Duck(24);
	}
	
	//构造函数。不写也没关系，编译器编译时会写（写在编译代码里？）
	public StackRef(){
		
	}
}
