package Chap09;
 
/**
 * 2013.03.27
 * Michel
 */
import java.util.ArrayList;
public class RetentionBot {
	RetentionBot(ArrayList rlist){
		rlist.add(new SimUnit("Retention"));
	}
}
