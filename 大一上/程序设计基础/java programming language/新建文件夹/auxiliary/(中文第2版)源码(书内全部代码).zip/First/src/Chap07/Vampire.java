package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Vampire extends Monster {
	boolean frighten(int x){
		System.out.println("a bite?");
		return false;
	}
}
