package Chap08;

/**
 * 2013.03.27
 * Michel
 */
public interface Nose {
	public int iMethod();
}
