package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Rowboat extends Boat {
	public void rowTheBoat(){
		System.out.println("stroke natasha");
	}
}
