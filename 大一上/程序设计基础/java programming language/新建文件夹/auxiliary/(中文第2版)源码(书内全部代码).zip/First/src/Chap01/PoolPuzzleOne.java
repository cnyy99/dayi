package Chap01;

//2013.03.18
//Michel
public class PoolPuzzleOne {
	public static void main(String[] args){
//		int x=0;
//		
//		while(x<1){
//			  
//			if(x<1){
//				System.out.print("a");
//				System.out.print(" ");
//				System.out.print("noise");
//			}
//			
//			if(){
//				System.out.print("annoys"); 
//				x=x+1;
//			}
//			
//			if(x==1){
//				System.out.print("an");
//				System.out.print(" oyster");
//			}
//			
//			if(){
//				
//			}
//			System.out.print("");
//			
//		}
	}
}
