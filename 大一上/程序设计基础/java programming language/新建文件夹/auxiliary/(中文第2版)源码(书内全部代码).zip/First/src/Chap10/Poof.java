package Chap10;

/**
 * 2013.03.28
 * Michel
 * final的method
 */
public class Poof { 
	final void calcWhuffie() {
		//final方法不能被子类覆盖
	} 
}
