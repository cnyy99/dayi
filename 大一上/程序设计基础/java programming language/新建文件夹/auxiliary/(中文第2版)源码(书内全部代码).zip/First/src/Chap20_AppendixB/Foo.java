package Chap20_AppendixB;

/**
 * 2013.04.22
 * Michel
 */
class Foo {
	public static void main(String[] args){
		new Foo().go();
	}
	
	void go(){
		
	}
}
