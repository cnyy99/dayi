package Chap08;

/**
 * 2013.03.26
 * Michel
 */
public interface Pet {
	//接口的方法一定是抽象的，所以必须以分号结束。记住，它们没有内容！
	public abstract void beFriendly();
	public abstract void play();
}
