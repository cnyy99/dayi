package Chap08;

/**
 * 2013.03.26
 * Michel
 */
public abstract class Report {
	void runReport(){
		System.out.println("设置报告");
	}
	
	void printReport(){
		System.out.println("输出");
	}
}
