package Chap10;

/**
 * 2013.03.27
 * Michel
 */
public class Foo {
	//静态final变量初始化方法1
	public static final int FOO_X =25;
}
