package Chap07;

/**
 * 2013.03.26
 * Michel
 */
public class Sailboat extends Boat{
	public void move(){
		System.out.println("hoist sail ");
	}
}
