package Chap02;

//2013.03.19
//Michel
public class DVDPlayer {
	boolean canRecord = false;
	void recordDVD() {
		System.out.println("DVD recording");
	}
}
